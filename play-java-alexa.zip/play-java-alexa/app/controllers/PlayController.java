package controllers;

import com.amazon.speech.Sdk;
import com.amazon.speech.json.SpeechletRequestEnvelope;
import com.amazon.speech.slu.Intent;
import com.amazon.speech.speechlet.*;
import com.amazon.speech.speechlet.authentication.SpeechletRequestSignatureVerifier;
import com.amazon.speech.speechlet.servlet.ServletSpeechletRequestHandler;
import com.amazon.speech.speechlet.servlet.SpeechletServlet;
import com.google.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import play.mvc.Controller;
import play.mvc.Result;
import service.AlexaService;
import util.App;

import javax.inject.Singleton;
import javax.servlet.http.HttpServletResponse;
import java.util.Optional;

/**
 * Controller For Handling Alexa Functionality.
 */
@Singleton
public class PlayController extends Controller implements SpeechletV2 {

    private static final Logger log = LoggerFactory.getLogger(PlayController.class);

    private final boolean disableRequestSignatureCheck;

    @Inject
    private transient ServletSpeechletRequestHandler speechletRequestHandler;

    @Inject
    private SpeechletServlet speechletServlet;

    @Inject
    private AlexaService alexaService;

    public PlayController() {
        App.prepareSystemProperties();

        // An invalid value or null will turn signature checking on.
        disableRequestSignatureCheck =
                Boolean.parseBoolean(System.getProperty(Sdk.DISABLE_REQUEST_SIGNATURE_CHECK_SYSTEM_PROPERTY));
    }

    public Result handlePostResponse() {
        Result result;
        try {
            byte[] serializedSpeechletRequest = request().body().asJson().toString().getBytes();
            if (disableRequestSignatureCheck) {
                log.warn("Warning: Speechlet request signature verification has been disabled!");
            } else {
                // Verify the authenticity of the request by checking the provided signature &
                // certificate.
                Optional<String> signatureRequest = request().header(Sdk.SIGNATURE_REQUEST_HEADER);
                Optional<String> signatureCertificateRequest = request().header(Sdk.SIGNATURE_CERTIFICATE_CHAIN_URL_REQUEST_HEADER);

                SpeechletRequestSignatureVerifier.checkRequestSignature(serializedSpeechletRequest,
                        signatureRequest.isPresent() ? signatureRequest.get() : null,
                        signatureCertificateRequest.isPresent() ? signatureCertificateRequest.get() : null);
            }

            // Generate JSON and send back the response
            byte[] outputBytes = speechletRequestHandler.handleSpeechletCall(this, serializedSpeechletRequest);
            String outputResult = new String(outputBytes, "UTF-8");
            log.warn("Output result is: " + outputResult);

            result = ok(outputResult).as("application/json");
        } catch (SpeechletRequestHandlerException | SecurityException ex) {
            log.error("Exception occurred in handlePostResponse method, returning status code {}", HttpServletResponse.SC_BAD_REQUEST, ex);
            result = badRequest(ex.getMessage());
        } catch (Exception ex) {
            log.error("Exception occurred in handlePostResponse method, returning status code {}", HttpServletResponse.SC_INTERNAL_SERVER_ERROR, ex);
            result = internalServerError(ex.getMessage());
        }
        return result;
    }

    @Override
    public void onSessionStarted(SpeechletRequestEnvelope<SessionStartedRequest> requestEnvelope) {
        log.info("onSessionStarted requestId={}, sessionId={}", requestEnvelope.getRequest().getRequestId(),
                requestEnvelope.getSession().getSessionId());
        // any initialization logic goes here
    }

    @Override
    public SpeechletResponse onLaunch(SpeechletRequestEnvelope<LaunchRequest> requestEnvelope) {
        log.info("onLaunch requestId={}, sessionId={}", requestEnvelope.getRequest().getRequestId(),
                requestEnvelope.getSession().getSessionId());
        return alexaService.getWelcomeResponse();
    }

    @Override
    public SpeechletResponse onIntent(SpeechletRequestEnvelope<IntentRequest> requestEnvelope) {
        log.info("onIntent requestId={}, sessionId={}", requestEnvelope.getRequest().getRequestId(),
                requestEnvelope.getSession().getSessionId());

        Intent intent = requestEnvelope.getRequest().getIntent();
        String intentName = (intent != null) ? intent.getName() : null;

        if ("HelloWorldIntent".equals(intentName)) {
            return alexaService.getHelloResponse();
        } else if ("AMAZON.HelpIntent".equals(intentName)) {
            return alexaService.getHelpResponse();
        }
        return null;
    }

    @Override
    public void onSessionEnded(SpeechletRequestEnvelope<SessionEndedRequest> requestEnvelope) {
        log.info("onSessionEnded requestId={}, sessionId={}", requestEnvelope.getRequest().getRequestId(),
                requestEnvelope.getSession().getSessionId());
        // any cleanup logic goes here
    }
}
